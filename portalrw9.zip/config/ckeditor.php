<?php

return [
    'disk' => 'public'
];